import SettingGeneralForm from '@/components/setting/settingGeneralForm'
import React from 'react'

const page = () => {
    return (
        <>
            <SettingGeneralForm />
        </>
    )
}

export default page