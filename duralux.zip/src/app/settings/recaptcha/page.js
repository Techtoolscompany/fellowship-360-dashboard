import SettingsRecaptchaForm from '@/components/setting/settingsRecaptchaForm'
import React from 'react'

const page = () => {
    return (
        <><SettingsRecaptchaForm /></>
    )
}

export default page