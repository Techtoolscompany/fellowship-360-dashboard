import SettingsTagsForm from '@/components/setting/settingsTagsForm'
import React from 'react'

const page = () => {
    return (
        <>
            <SettingsTagsForm />
        </>
    )
}

export default page