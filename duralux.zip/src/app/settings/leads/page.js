import SettingsLeadsForm from '@/components/setting/settingsLeadsForm'
import React from 'react'

const page = () => {
    return (
        <SettingsLeadsForm />

    )
}

export default page