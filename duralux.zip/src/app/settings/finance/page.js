import SettingsFinanceForm from '@/components/setting/settingsFinanceForm'
import React from 'react'

const page = () => {
  return (
    <SettingsFinanceForm />
  )
}

export default page