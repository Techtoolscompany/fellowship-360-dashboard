import SettingsEmailForm from '@/components/setting/settingsEmailForm'
import React from 'react'

const page = () => {
    return (
        <><SettingsEmailForm /></>
    )
}

export default page