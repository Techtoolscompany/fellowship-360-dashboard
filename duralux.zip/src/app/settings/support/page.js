import SettingsSupportForm from '@/components/setting/settingsSupportForm'
import React from 'react'

const page = () => {
    return (
        <SettingsSupportForm />
    )
}

export default page