import SettingsGatewaysForm from '@/components/setting/settingsGatewaysForm'
import React from 'react'

const page = () => {
    return (
        <SettingsGatewaysForm />
    )
}

export default page