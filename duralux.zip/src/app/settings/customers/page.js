import SettingsCustomersForm from '@/components/setting/settingsCustomersForm'
import React from 'react'

const page = () => {
    return (
        <SettingsCustomersForm />
    )
}

export default page