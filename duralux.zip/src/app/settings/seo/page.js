import SettingSeoForm from '@/components/setting/settingSeoForm'
import React from 'react'

const page = () => {
    return (
        <>
            <SettingSeoForm />
        </>
    )
}

export default page