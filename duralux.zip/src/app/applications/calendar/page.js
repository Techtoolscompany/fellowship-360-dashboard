import CalenderContent from '@/components/calender/CalenderContent'
import React from 'react'

const page = () => {
    return (
        <>
            <CalenderContent />
        </>
    )
}

export default page