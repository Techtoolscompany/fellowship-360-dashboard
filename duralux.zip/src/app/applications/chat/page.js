import React from 'react'
import ChatContent from '@/components/chats/ChatContent'

const AppsChat = () => {
  return (
    <>
      <ChatContent />
    </>
  )
}

export default AppsChat