import NotesContent from '@/components/notes/NotesContent'
import React from 'react'

const page = () => {
  return (
    <>
      <NotesContent />
    </>
  )
}

export default page