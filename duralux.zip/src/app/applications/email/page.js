import React from 'react'
import EmailContent from '@/components/emails/EmailContent'

const page = () => {
  return (
    <>
         <EmailContent />
    </>
  )
}

export default page