import StorageContent from '@/components/storage/StorageContent'
import React from 'react'

const page = () => {
    return (
        <>
            <StorageContent />
        </>
    )
}

export default page