import RegisterForm from '@/components/authentication/RegisterForm'
import Image from 'next/image'
import React from 'react'

const page = () => {
  return (
    <main className="auth-creative-wrapper">
      <div className="auth-creative-inner">
        <div className="creative-card-wrapper">
          <div className="card my-4 overflow-hidden" style={{ zIndex: 1 }}>
            <div className="row flex-1 g-0">
              <div className="col-lg-6 h-100 my-auto">
                <div className="wd-50 bg-white p-2 rounded-circle shadow-lg position-absolute translate-middle top-50 start-50">
                  <img src="/images/logo-abbr.png" alt="img" className="img-fluid" />
                </div>
                <div className="creative-card-body card-body p-sm-5">
                  <RegisterForm path={"/authentication/login/creative"} />
                </div>
              </div>
              <div className="col-lg-6 bg-primary">
                <div className="h-100 d-flex align-items-center justify-content-center">
                  <Image width={499} height={499} sizes='100vw' src="/images/auth/auth-user.png" alt="img" className="img-fluid" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}

export default page